package com.example.exam;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CreedsValidator {
    public boolean isValidEmail(final String email) {

        Pattern pattern;
        Matcher matcher;

        final String PASSWORD_PATTERN = "[a-zA-Z0-9]+@[a-zA-Z0-9]+\\.[a-z]{1,3}";

        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(email);

        return matcher.matches();

    }

    public boolean isNotEmpty(final String value) {

        return value.length() > 1;

    }
}
