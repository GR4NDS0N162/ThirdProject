package com.example.exam;

public class LogModel {
    private String email;
    private String password;
    public LogModel(String email, String password) {
        this.email = email;
        this.password = password;
    }
    public String getEmail() {
        return email;
    }
    public String getPassword() {
        return password;
    }


}
