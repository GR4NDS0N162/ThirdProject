package com.example.exam;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.ui.AppBarConfiguration;

import com.example.exam.databinding.ActivityMainBinding;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();

        Typeface roboto = Typeface.createFromAsset(this.getAssets(),
                "font/Roboto-Regular.ttf");
        ((EditText)findViewById(R.id.editTextEmail)).setTypeface(roboto);

        ((EditText)findViewById(R.id.editTextPassword)).setTypeface(roboto);


        Button register = findViewById(R.id.button2);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });

        Button login = findViewById(R.id.button);

        EditText emailEditText = findViewById(R.id.editTextEmail);
        EditText passwordEditText = findViewById(R.id.editTextPassword);

        login.setOnClickListener(new View.OnClickListener() {



            CreedsValidator validator = new CreedsValidator();

            @Override
            public void onClick(View view) {
                if(!validator.isValidEmail(emailEditText.getText().toString())) {
                    WindowError windowErrorFragment = new WindowError("Ошибка", "Почта введена неверно", "ОК");
                    FragmentManager manager = getSupportFragmentManager();

                    FragmentTransaction transaction = manager.beginTransaction();
                    windowErrorFragment.show(transaction, "dialog");
                    return;
                }

                if(!validator.isNotEmpty(passwordEditText.getText().toString())) {
                    WindowError windowErrorFragment = new WindowError("Ошибка", "Введите пароль!", "ОК");
                    FragmentManager manager = getSupportFragmentManager();

                    FragmentTransaction transaction = manager.beginTransaction();
                    windowErrorFragment.show(transaction, "dialog");
                    return;
                }


                emailEditText.setEnabled(false);
                passwordEditText.setEnabled(false);
                login.setEnabled(false);
                register.setEnabled(false);

                APIWorker.getInstance().getJSONApi().login(
                        new LogModel(emailEditText.getText().toString(), passwordEditText.getText().toString())).enqueue(new Callback<LoginResp>() {
                    @Override
                    public void onResponse(Call<LoginResp> call, Response<LoginResp> response) {

                        emailEditText.setEnabled(true);
                        passwordEditText.setEnabled(true);
                        login.setEnabled(true);
                        register.setEnabled(true);
                    }



                    @Override
                    public void onFailure(Call<LoginResp> call, Throwable t) {
                        emailEditText.setEnabled(true);
                        passwordEditText.setEnabled(true);
                        login.setEnabled(true);
                        register.setEnabled(true);
                        WindowError windowErrorFragment = new WindowError("Ошибка", "Нет подключения к серверу", "ОК");
                        FragmentManager manager = getSupportFragmentManager();




                        FragmentTransaction transaction = manager.beginTransaction();
                        windowErrorFragment.show(transaction, "dialog");
                    }
                });

            }


        });

    }


}