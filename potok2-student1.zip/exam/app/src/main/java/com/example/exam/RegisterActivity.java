package com.example.exam;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();
        setContentView(R.layout.activity_reg);
        Button signInButton = findViewById(R.id.buttonRegisterIHaveAccount);

        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        EditText regName = findViewById(R.id.regName);
        EditText regSurname = findViewById(R.id.regSurname);
        EditText regEmail = findViewById(R.id.regEmail);
        EditText regPassword = findViewById(R.id.regPassword);
        EditText regPasswordRepeat = findViewById(R.id.regPasswordRepeat);
        Button register = findViewById(R.id.buttonRegister);
        register.setOnClickListener(new View.OnClickListener() {

            CreedsValidator validator = new CreedsValidator();
            @Override
            public void onClick(View view) {
                if(!validator.isNotEmpty(regName.getText().toString())) {
                    WindowError windowErrorFragment = new WindowError("Ошибка", "Введите Имя!", "ОК");
                    FragmentManager manager = getSupportFragmentManager();

                    FragmentTransaction transaction = manager.beginTransaction();
                    windowErrorFragment.show(transaction, "dialog");
                    return;
                }


                if(!validator.isNotEmpty(regSurname.getText().toString())) {
                    WindowError windowErrorFragment = new WindowError("Ошибка", "Введите Фамилию!", "ОК");
                    FragmentManager manager = getSupportFragmentManager();

                    FragmentTransaction transaction = manager.beginTransaction();
                    windowErrorFragment.show(transaction, "dialog");
                    return;
                }


                if(!validator.isValidEmail(regEmail.getText().toString())) {
                    WindowError windowErrorFragment = new WindowError("Ошибка", "Почта введена неверно", "ОК");
                    FragmentManager manager = getSupportFragmentManager();

                    FragmentTransaction transaction = manager.beginTransaction();
                    windowErrorFragment.show(transaction, "dialog");
                    return;
                }


                if(!validator.isNotEmpty(regPassword.getText().toString())) {
                    WindowError windowErrorFragment = new WindowError("Ошибка", "Введите пароль!", "ОК");
                    FragmentManager manager = getSupportFragmentManager();

                    FragmentTransaction transaction = manager.beginTransaction();
                    windowErrorFragment.show(transaction, "dialog");
                    return;
                }


                if(!regPassword.getText().toString().equals(regPasswordRepeat.getText().toString())) {
                    WindowError windowErrorFragment = new WindowError("Ошибка", "Пароли разные! Проверьте ещёр раз!", "ОК");
                    FragmentManager manager = getSupportFragmentManager();


                    FragmentTransaction transaction = manager.beginTransaction();
                    windowErrorFragment.show(transaction, "dialog");
                    return;
                }
            }
        });

    }

}