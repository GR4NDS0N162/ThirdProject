package com.example.exam;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.ui.AppBarConfiguration;

import com.example.exam.databinding.ActivityMainBinding;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.hide();
        com.example.exam.databinding.ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();

        Typeface roboto = Typeface.createFromAsset(this.getAssets(),
                "font/Roboto-Regular.ttf");
        ((EditText) findViewById(R.id.emailField)).setTypeface(roboto);
        ((EditText) findViewById(R.id.passwordField)).setTypeface(roboto);

        Button register = findViewById(R.id.signupButton);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });

        Button login = findViewById(R.id.loginButton);

        EditText emailEditText = findViewById(R.id.emailField);
        EditText passwordEditText = findViewById(R.id.passwordField);

        login.setOnClickListener(new View.OnClickListener() {
            Validator validator = new Validator();

            @Override
            public void onClick(View view) {
                if (validator.isNotValidEmail(emailEditText.getText().toString())) {
                    ErrorDialog errorDialogFragment = new ErrorDialog("Ошибка", "Неверный формат почты", "ОК");
                    FragmentManager manager = getSupportFragmentManager();

                    FragmentTransaction transaction = manager.beginTransaction();
                    errorDialogFragment.show(transaction, "dialog");
                    return;
                }

                if (validator.isEmpty(passwordEditText.getText().toString())) {
                    ErrorDialog errorDialogFragment = new ErrorDialog("Ошибка", "Пароль не может быть пустым", "ОК");
                    FragmentManager manager = getSupportFragmentManager();

                    FragmentTransaction transaction = manager.beginTransaction();
                    errorDialogFragment.show(transaction, "dialog");
                    return;
                }
                emailEditText.setEnabled(false);
                passwordEditText.setEnabled(false);
                login.setEnabled(false);
                register.setEnabled(false);
                APIWorker.getInstance().getJSONApi().login(
                        new LoginModel(emailEditText.getText().toString(), passwordEditText.getText().toString())).enqueue(new Callback<LoginResponse>() {
                    @Override
                    public void onResponse(@NonNull Call<LoginResponse> call, @NonNull Response<LoginResponse> response) {
                        emailEditText.setEnabled(true);
                        passwordEditText.setEnabled(true);
                        login.setEnabled(true);
                        register.setEnabled(true);
                    }

                    @Override
                    public void onFailure(@NonNull Call<LoginResponse> call, @NonNull Throwable t) {
                        emailEditText.setEnabled(true);
                        passwordEditText.setEnabled(true);
                        login.setEnabled(true);
                        register.setEnabled(true);
                        ErrorDialog errorDialogFragment = new ErrorDialog("Ошибка", "Ошибка подключения к серверу", "ОК");
                        FragmentManager manager = getSupportFragmentManager();

                        FragmentTransaction transaction = manager.beginTransaction();
                        errorDialogFragment.show(transaction, "dialog");
                    }
                });
            }
        });
    }
}