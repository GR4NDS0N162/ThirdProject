package com.example.exam;

public class LoginResponse {

}
