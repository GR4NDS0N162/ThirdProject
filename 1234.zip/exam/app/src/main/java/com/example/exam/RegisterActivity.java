package com.example.exam;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class RegisterActivity extends AppCompatActivity {

    public static final String TAG_DIALOG = "dialog";
    public static final String ERROR_TITLE = "Ошибка";
    public static final String BTN_OK = "ОК";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.hide();
        setContentView(R.layout.activity_register);

        Button signInButton = findViewById(R.id.buttonRegisterIHaveAccount);

        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        EditText regName = findViewById(R.id.regName);
        EditText regSurname = findViewById(R.id.regSurname);
        EditText regEmail = findViewById(R.id.regEmail);
        EditText regPassword = findViewById(R.id.regPassword);
        EditText regPasswordRepeat = findViewById(R.id.regPasswordRepeat);

        Button register = findViewById(R.id.buttonRegister);
        register.setOnClickListener(new View.OnClickListener() {

            Validator validator = new Validator();

            @Override
            public void onClick(View view) {

                if (validator.isEmpty(regName.getText().toString())) {
                    ErrorDialog errorDialogFragment = new ErrorDialog(ERROR_TITLE, "Имя не может быть пустым", BTN_OK);
                    FragmentManager manager = getSupportFragmentManager();
                    FragmentTransaction transaction = manager.beginTransaction();
                    errorDialogFragment.show(transaction, TAG_DIALOG);
                    return;
                }

                if (validator.isEmpty(regSurname.getText().toString())) {
                    ErrorDialog errorDialogFragment = new ErrorDialog(ERROR_TITLE, "Фамилия не может быть пустой", BTN_OK);
                    FragmentManager manager = getSupportFragmentManager();
                    FragmentTransaction transaction = manager.beginTransaction();
                    errorDialogFragment.show(transaction, TAG_DIALOG);
                    return;
                }

                if (validator.isNotValidEmail(regEmail.getText().toString())) {
                    ErrorDialog errorDialogFragment = new ErrorDialog(ERROR_TITLE, "Неверный формат почты", BTN_OK);
                    FragmentManager manager = getSupportFragmentManager();
                    FragmentTransaction transaction = manager.beginTransaction();
                    errorDialogFragment.show(transaction, TAG_DIALOG);
                    return;
                }

                if (validator.isEmpty(regPassword.getText().toString())) {
                    ErrorDialog errorDialogFragment = new ErrorDialog(ERROR_TITLE, "Пароль не может быть пустым", BTN_OK);
                    FragmentManager manager = getSupportFragmentManager();
                    FragmentTransaction transaction = manager.beginTransaction();
                    errorDialogFragment.show(transaction, TAG_DIALOG);
                    return;
                }

                if (!regPassword.getText().toString().equals(regPasswordRepeat.getText().toString())) {
                    ErrorDialog errorDialogFragment = new ErrorDialog(ERROR_TITLE, "Пароли должны совпадать", BTN_OK);
                    FragmentManager manager = getSupportFragmentManager();
                    FragmentTransaction transaction = manager.beginTransaction();
                    errorDialogFragment.show(transaction, TAG_DIALOG);
                }
            }
        });
    }
}