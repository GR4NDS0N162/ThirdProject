package com.example.exam;


import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface APIPatterns {
    @POST("user/login")
    Call<LoginResponse> login(@Body LoginModel loginModel);
}
