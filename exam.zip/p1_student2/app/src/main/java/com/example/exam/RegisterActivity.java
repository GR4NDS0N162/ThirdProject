package com.example.exam;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();
        setContentView(R.layout.activity_register);

        Button signInButton = findViewById(R.id.buttonRegisterIHaveAccount);

        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        EditText regName = findViewById(R.id.regName);
        EditText regSurname = findViewById(R.id.regSurname);
        EditText regEmail = findViewById(R.id.regEmail);
        EditText regPassword = findViewById(R.id.regPassword);
        EditText regPasswordRepeat = findViewById(R.id.regPasswordRepeat);

        Button register = findViewById(R.id.buttonRegister);
        register.setOnClickListener(new View.OnClickListener() {

            CredsValidator validator = new CredsValidator();
            @Override
            public void onClick(View view) {

                if(!validator.isNotEmpty(regName.getText().toString())) {
                    MyDialog myDialogFragment = new MyDialog("Ошибка", "Имя не может быть пустым", "ОК");
                    FragmentManager manager = getSupportFragmentManager();

                    FragmentTransaction transaction = manager.beginTransaction();
                    myDialogFragment.show(transaction, "dialog");
                    return;
                }

                if(!validator.isNotEmpty(regSurname.getText().toString())) {
                    MyDialog myDialogFragment = new MyDialog("Ошибка", "Фамилия не может быть пустой", "ОК");
                    FragmentManager manager = getSupportFragmentManager();

                    FragmentTransaction transaction = manager.beginTransaction();
                    myDialogFragment.show(transaction, "dialog");
                    return;
                }

                if(!validator.isValidEmail(regEmail.getText().toString())) {
                    MyDialog myDialogFragment = new MyDialog("Ошибка", "Неверный формат почты", "ОК");
                    FragmentManager manager = getSupportFragmentManager();

                    FragmentTransaction transaction = manager.beginTransaction();
                    myDialogFragment.show(transaction, "dialog");
                    return;
                }

                if(!validator.isNotEmpty(regPassword.getText().toString())) {
                    MyDialog myDialogFragment = new MyDialog("Ошибка", "Пароль не может быть пустым", "ОК");
                    FragmentManager manager = getSupportFragmentManager();

                    FragmentTransaction transaction = manager.beginTransaction();
                    myDialogFragment.show(transaction, "dialog");
                    return;
                }

                if(!regPassword.getText().toString().equals(regPasswordRepeat.getText().toString())) {
                    MyDialog myDialogFragment = new MyDialog("Ошибка", "Пароли должны совпадать", "ОК");
                    FragmentManager manager = getSupportFragmentManager();

                    FragmentTransaction transaction = manager.beginTransaction();
                    myDialogFragment.show(transaction, "dialog");
                    return;
                }


            }
        });
    }
}