package com.example.exam;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class APIWorker {
    private static APIWorker mInstance;
    private static final String BASE_URL = "http://cinema.areas.su";
    private Retrofit mRetrofit;

    private APIWorker() {
        mRetrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
    }


    public static APIWorker getInstance() {
        if (mInstance == null) {
            mInstance = new APIWorker();
        }
        return mInstance;
    }

    public APIPatterns getJSONApi() {
        return mRetrofit.create(APIPatterns.class);
    }
}